


 CLUSTAL 2.1 Multiple Sequence Alignments


Sequence format is Pearson
Sequence 1: sp|P12263|FA8_PIG       2363 aa
Sequence 2: sp|P00451|FA8_HUMAN     2363 aa
Sequence 3: sp|Q06194|FA8_MOUSE     2363 aa

           sp|P12263|FA8_PIG 
           sp|P00451|FA8_HUMAN 
           sp|Q06194|FA8_MOUSE 
           sp|P00451|FA8_HUMAN 
           sp|Q06194|FA8_MOUSE 
           sp|Q06194|FA8_MOUSE 
perc identity file created:   [/nfs/public/rw/es/projects/wp-jdispatcher/sources/prod-hx/jobs/clustalo/interactive/20260409/1106/clustalo-I20260409-110752-0731-44526992-p2m.sqr.pim]

Phylogenetic tree file created:   [/nfs/public/rw/es/projects/wp-jdispatcher/sources/prod-hx/jobs/clustalo/interactive/20260409/1106/clustalo-I20260409-110752-0731-44526992-p2m.sqr.ph]

